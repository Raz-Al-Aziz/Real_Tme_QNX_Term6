#include <iostream>
#include <semaphore.h>
#include <csignal>
#include <cstdlib>
#include <cstring>
#include <unistd.h>

sem_t *semaphore;

void exitFactory(int signal) {
	std::system("pkill -SIGUSR1 thread_factory");
	sem_close(semaphore);
	sem_unlink("/my_semaphore");
	exit(EXIT_SUCCESS);
}

int main() {
	std::cout << "Thread Waker (PID: " << getpid() << ")" << std::endl;

	semaphore = sem_open("/my_semaphore", O_CREAT, S_IRUSR | S_IWUSR, 0);

	if (semaphore == SEM_FAILED) {
		perror("sem_open");
		exit(EXIT_FAILURE);
	}

	signal(SIGINT, exitFactory);

	while (true) {
		int numThreadsToWake;
		std::cout
				<< "How many threads do you want to wake up (enter 0 to exit)? ";
		std::cout.flush();

		if (!(std::cin >> numThreadsToWake) || numThreadsToWake < 0) {
			std::cout << "Invalid input. Please enter a valid number."
					<< std::endl;
			std::cin.clear();
			std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
			continue;
		}

		if (numThreadsToWake == 0) {
			break;
		}

		for (int i = 0; i < numThreadsToWake; i++) {
			sem_post(semaphore);
		}

		std::cout << "Waking up " << numThreadsToWake << " threads."
				<< std::endl;
	}

	sem_close(semaphore);

	std::cout << "Thread Waker: Exiting with success." << std::endl;
	exitFactory(0);

	return 0;
}
