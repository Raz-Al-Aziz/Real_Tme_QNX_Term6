#include <iostream>
#include <pthread.h>
#include <semaphore.h>
#include <signal.h>
#include <unistd.h>

sem_t *semaphore;
int *threadStatus;
pthread_t *threads;
int numChildren;
pthread_mutex_t outputMutex; // Mutex for synchronizing output

void* childThread(void *arg) {
	int threadID = *((int*) arg);

	// Print thread creation message
	pthread_mutex_lock(&outputMutex);
	std::cout << "Child thread " << threadID << " created. Thread ID: "
			<< threadID + 2 << std::endl;
	pthread_mutex_unlock(&outputMutex);

	threadStatus[threadID] = 0;

	while (true) {
		sem_wait(semaphore);
		if (threadStatus[threadID] != -1) {
			// Print unblocked message
			pthread_mutex_lock(&outputMutex);
			std::cout << "Child thread " << threadID << " unblocked. Status: "
					<< threadStatus[threadID] << std::endl;
			pthread_mutex_unlock(&outputMutex);
			sleep(5);
		} else {
			break;
		}
	}

	pthread_exit(NULL);
}

void handleSignal(int signal) {
	if (signal == SIGUSR1) {
		for (int i = 0; i < numChildren; i++) {
			if (threadStatus[i] != -1) {
				pthread_mutex_lock(&outputMutex);
				std::cout << "Child thread " << i << " unblocked. Status: -1"
						<< std::endl;
				pthread_mutex_unlock(&outputMutex);
				threadStatus[i] = -1;
			}
		}

		sem_close(semaphore);
		sem_unlink("/my_semaphore");

		free(threads);
		free(threadStatus);

		pthread_mutex_destroy(&outputMutex);

		std::cout << "Thread Factory: All threads finished, exiting."
				<< std::endl;
		exit(EXIT_SUCCESS);
	}
}

int main() {
	std::cout << "Enter the number of child threads: ";
	std::cin >> numChildren;

	threads = new pthread_t[numChildren];
	threadStatus = new int[numChildren];

	semaphore = sem_open("/my_semaphore", O_CREAT, S_IRUSR | S_IWUSR, 0);

	if (semaphore == SEM_FAILED) {
		perror("sem_open");
		exit(EXIT_FAILURE);
	}

	for (int i = 0; i < numChildren; i++) {
		threadStatus[i] = 0;
	}

	pthread_mutex_init(&outputMutex, NULL);

	signal(SIGUSR1, handleSignal);

	for (int i = 0; i < numChildren; ++i) {
		int *threadID = new int;
		*threadID = i;
		pthread_create(&threads[i], NULL, childThread, threadID);
	}

	for (int i = 0; i < numChildren; ++i) {
		pthread_join(threads[i], NULL);
	}

	std::cout << "Thread Factory: All threads finished, exiting." << std::endl;

	return 0;
}
