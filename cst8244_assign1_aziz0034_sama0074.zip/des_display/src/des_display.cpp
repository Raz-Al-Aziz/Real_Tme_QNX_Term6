#include <iostream>
#include <cstdlib>
#include <sys/neutrino.h>
#include <sys/dispatch.h>
#include "../../des_controller/src/des.h"

using namespace std;

send_t msg_received;
response_t response;

int main(void) {
    int chid;
    int rcvid;


    if ((chid = ChannelCreate(0)) == -1) {
    	//create the channel
        cerr << "ERROR: Channel not created" << endl;
        exit(EXIT_FAILURE);
    }

    cout << "The Display's is running as Process_id: " << getpid() << endl;

    while (true) {

    	//recieve messages from controller by calling msgRecieve
        if ((rcvid = MsgReceive(chid, &msg_received, sizeof(send_t), NULL)) == -1) {
            cerr << "Error receiving message from controller." << endl;
            return EXIT_FAILURE;
        }


        //Reply to controller by caling msgReply func with eok
        if (MsgReply(rcvid, EOK, &response, sizeof(response_t)) == -1) {
            cerr << "message unable to reply." << endl;
            return EXIT_FAILURE;
        }

        // if message equals id scan execute this block
        if ((msg_received.input == INPUT_LEFT_SCAN) || (msg_received.input == INPUT_RIGHT_SCAN)){
            cout << outMessage[OUTPUT_SCAN] << " " << msg_received.uniquePersonID << endl;
        //check if the messaged recived equals weighed , if true ,print message person been wieghed
        }
        else if (msg_received.input == INPUT_WEIGHT_SCAN){
            cout << "Person ID: " << msg_received.uniquePersonID << " has been weighed: " << msg_received.weight << ".\n";

        }else if (msg_received.input == INPUT_LEFT_UNLOCK){ cout << outMessage[OUTPUT_LEFT_UNLOCK] << endl;

        }else if (msg_received.input == INPUT_RIGHT_UNLOCK){ cout << outMessage[OUTPUT_RIGHT_UNLOCK] << endl;

        }else if (msg_received.input == INPUT_LEFT_OPEN){ cout << outMessage[OUTPUT_LEFT_OPEN] << endl;

        }else if (msg_received.input == INPUT_RIGHT_OPEN){ cout << outMessage[OUTPUT_RIGHT_OPEN] << endl;

        }else if (msg_received.input == INPUT_LEFT_CLOSE){ cout << outMessage[OUTPUT_LEFT_CLOSE] << endl;

        }else if (msg_received.input == INPUT_RIGHT_CLOSE){ cout << outMessage[OUTPUT_RIGHT_CLOSE] << endl;

        }else if (msg_received.input == INPUT_LEFT_LOCK){ cout << outMessage[OUTPUT_LEFT_LOCK] << endl;

        }else if (msg_received.input == INPUT_RIGHT_LOCK){ cout << outMessage[OUTPUT_RIGHT_LOCK] << endl;

        }else cout << outMessage[msg_received.input] << endl;

        // terminate progeram if equals to eit
        if (msg_received.input == INPUT_EXIT)
        	break;

        }


    ChannelDestroy(chid);
    return EXIT_SUCCESS;
}
