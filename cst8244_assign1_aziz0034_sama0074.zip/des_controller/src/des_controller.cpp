#include <iostream>
#include <cstdlib>
#include <cstring>
#include <sys/neutrino.h>
#include <sys/netmgr.h>
#include <sys/iofunc.h>
#include <sys/dispatch.h>
#include "./des.h"

using namespace std;

send_t msg_received;
response_t msg_response;

int main(int argc, char* argv[]) {
	//beggining state for finite state transition
    State starting_state = State_Start;
    pid_t show_pid;
    int flags = 0;
    int coid, chid, rcvid;
    int msg_send;


    if (argc != 2 ) {
        cout << "Missing PID :" << endl;
        return EXIT_FAILURE;
    }

    show_pid = atoi(argv[1]);
    if ((chid = ChannelCreate(flags)) == -1) {
        cerr << "ERROR: Could not create channel." << endl;
        perror(NULL);
        return EXIT_FAILURE;
    }

    if ((coid = ConnectAttach(0, show_pid, 1, _NTO_SIDE_CHANNEL, flags)) == -1) {
        cerr << "ERROR: Could not attach connection." << endl;
        perror(NULL);
        return EXIT_FAILURE;
    }

    cout << "The Controller is running as Process_id: " << getpid() << endl;

    while (true) {
        msg_send = 0;

        if ((rcvid = MsgReceive(chid, &msg_received, sizeof(send_t), NULL)) == -1) {
            cerr << "ERROR: Could not receive message from input." << endl;
            return EXIT_FAILURE;
        }

        if (msg_received.input == INPUT_EXIT) starting_state = STATE_EXIT;

        switch (starting_state) {
            case State_Start:
                if (msg_received.input == INPUT_LEFT_SCAN) {
                	starting_state = STATE_LEFT_SCAN;
                    msg_send = 1;
                } else if (msg_received.input == INPUT_RIGHT_SCAN) {
                	starting_state = STATE_RIGHT_SCAN;
                    msg_send = 1;
                }
                break;
            case STATE_LEFT_SCAN:
                if (msg_received.input == INPUT_LEFT_UNLOCK) {
                	starting_state = STATE_IN_LEFT_UNLOCK;
                    msg_send = 1;
                }
                break;
            case STATE_RIGHT_SCAN:
                if (msg_received.input == INPUT_RIGHT_UNLOCK) {
                	starting_state = STATE_OUT_RIGHT_UNLOCK;
                    msg_send = 1;
                }
                break;
            // Handle other cases similarly
            case STATE_OUT_LEFT_OPEN:
                if (msg_received.input == INPUT_LEFT_CLOSE) {
                	starting_state = STATE_LEFT_CLOSE;
                    msg_send = 1;
                }
                break;
            case STATE_LEFT_CLOSE:
                if (msg_received.input == INPUT_LEFT_CLOSE) {
                	starting_state = State_Start;
                    msg_send = 1;
                }
                break;
            case STATE_EXIT:
                MsgSend(coid, &msg_received, sizeof(send_t), &msg_response, sizeof(response_t));
                MsgReply(rcvid, EOK, &msg_response, sizeof(response_t));
                return EXIT_SUCCESS;
        }

        if (msg_send == 1) {
            if (MsgSend(coid, &msg_received, sizeof(send_t), &msg_response, sizeof(response_t)) == -1) {
                cerr << "ERROR: Could not send message." << endl;
                perror(NULL);
                exit(EXIT_FAILURE);
            }
        }

        if (MsgReply(rcvid, EOK, &msg_response, sizeof(response_t)) == -1) {
            cerr << "ERROR: A Reply Was Not Sent To Next Message  ." << endl;
            perror(NULL);
            exit(EXIT_FAILURE);
        }
    }

    ConnectDetach(coid);
    ChannelDestroy(chid);
    return EXIT_SUCCESS;
}
