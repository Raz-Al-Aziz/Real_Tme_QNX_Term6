/*
 * des.h
 *
 *  Created on: Nov. 6, 2023
 *      Author: Ramses
 */

#ifndef DES_MVA_H_
#define DES_MVA_H_

#include <string>

enum Output_t {
	OUTPUT_READY = 0,
	OUTPUT_SCAN = 1,
	OUTPUT_WEIGHT_SCAN = 2,
	OUTPUT_LEFT_OPEN = 3,
	OUTPUT_RIGHT_OPEN = 4,
	OUTPUT_LEFT_CLOSE = 5,
	OUTPUT_RIGHT_CLOSE = 6,
	OUTPUT_LEFT_UNLOCK = 7,
	OUTPUT_RIGHT_UNLOCK = 8,
	OUTPUT_RIGHT_LOCK = 9,
	OUTPUT_LEFT_LOCK = 10,
	OUTPUT_EXIT = 11
};

enum Input_t {
	INPUT_LEFT_SCAN = 0,
	INPUT_RIGHT_SCAN = 1,
	INPUT_LEFT_UNLOCK = 2,
	INPUT_LEFT_OPEN = 3,
	INPUT_LEFT_CLOSE = 4,
	INPUT_LEFT_LOCK = 5,
	INPUT_WEIGHT_SCAN = 6,
	INPUT_RIGHT_UNLOCK = 7,
	INPUT_RIGHT_OPEN = 8,
	INPUT_RIGHT_CLOSE = 9,
	INPUT_RIGHT_LOCK = 10,
	INPUT_EXIT = 11
};

enum State {
	State_Start = 0,
	STATE_LEFT_SCAN = 1,
	STATE_RIGHT_SCAN = 2,
	STATE_IN_LEFT_UNLOCK = 3,
	STATE_IN_RIGHT_UNLOCK = 4,
	STATE_IN_LEFT_OPEN = 5,
	STATE_IN_RIGHT_OPEN = 6,
	STATE_WEIGHT_SCAN = 7,
	STATE_IN_LEFT_CLOSE = 8,
	STATE_IN_LEFT_LOCK = 9,
	STATE_IN_RIGHT_CLOSE = 10,
	STATE_OUT_RIGHT_UNLOCK = 11,
	STATE_OUT_RIGHT_OPEN = 12,
	STATE_OUT_WEIGHT_SCAN = 13,
	STATE_OUT_RIGHT_CLOSE = 14,
	STATE_OUT_RIGHT_LOCK = 15,
	STATE_OUT_LEFT_UNLOCK = 16,
	STATE_OUT_LEFT_OPEN = 17,
	STATE_LEFT_CLOSE = 18,
	STATE_EXIT = 19
};



// Messages sent to display
const std::string outMessage[] = {
    "Controller PID: ",//1
    "Person Scanned ID, ID = : ",//2
    "Person weighed , Weight = : ",//3
    "Person opened left door.",//4
    "Person opened right door.",//5
    "Left door closed (automatically).",//6
    "Right door closed (automatically) .",//7
    "Left door unlocked by Guard. ",//8
    "Right door unlocked by Guard. ",//9
    "Right door locked by Guard. ",//10
    "Left door locked by Guard. ",//11
    "Exiting..."//12
};

// Response data
struct Response {
	std::string messageErr;;
    int servResponse;;

}typedef response_t;

// Input data
struct Send {
    Input_t input;
    float weight;
    int uniquePersonID;
}typedef send_t;

#endif  // DES_MVA_H_
