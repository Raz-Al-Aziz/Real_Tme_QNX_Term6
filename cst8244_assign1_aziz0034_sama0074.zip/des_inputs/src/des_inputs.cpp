#include <iostream>
#include <string>
#include <cstdlib>
#include <sys/neutrino.h>
#include <sys/dispatch.h>
#include <sys/netmgr.h>
#include "../../des_controller/src/des.h"
using namespace std;


const string LEFT_SCAN = "ls";
const string RIGHT_SCAN = "rs";


response_t msg_receive;
send_t msg_send;

int coid;

int main(int argc, char *args[]) {
	string input;
	double weight;
	int uniquePersonID;
	pid_t controller_pid;

	if (argc != 2) {

		cout << "Missing PID" << endl;
		return EXIT_FAILURE;
	}

	controller_pid = atoi(args[1]);
	coid = ConnectAttach(ND_LOCAL_NODE, controller_pid, 1, _NTO_SIDE_CHANNEL,
			0);

	if (coid == -1) {
		cerr << "ERROR: Controller did not establish connection" << endl;
		std::exit(EXIT_FAILURE);
	}
	//print the menu for the program
	cout
			<< "Enter the event type (ls = left scan, rs = right scan, ws = weight scale, lo = left open, ro = right open, lc = left closed, rc = right closed, gru = guard right unlock, grl = guard right lock, gll = guard left lock, glu = guard left unlock)"
			<< endl;

	while (true) {
		cin >> input;

		// Clear buffer once its been read
		cin.ignore(numeric_limits<streamsize>max(), '\n');

		if (input == LEFT_SCAN || input == RIGHT_SCAN) {
			cout << "Enter The persons ID:" << endl;
			cin >> uniquePersonID;
			msg_send.uniquePersonID = uniquePersonID;
			if (input == LEFT_SCAN) {
				msg_send.input = INPUT_LEFT_SCAN;

				//std::cout << "Person Scanned ID, ID = : " << person_id << std::endl;
			}else if (input == RIGHT_SCAN) {
				msg_send.input = INPUT_RIGHT_SCAN;
				cout << outMessage[OUTPUT_SCAN] << " " << msg_send.uniquePersonID << endl;
				//std::cout << "Person Scanned ID, ID = : " << person_id
					//<< std::endl;
			}
			//msg_send.input = (input == "ls") ? LEFT_SCAN_I : RIGHT_SCAN_I;
		} else if (input == "ws") {
			cout << "Enter The Persons Weight :" << endl;
			cin >> weight; //123
			msg_send.weight = weight;
			msg_send.input = INPUT_WEIGHT_SCAN;
			cout << outMessage[OUTPUT_WEIGHT_SCAN] << " " << weight
					<< endl;

		} else if (input == "lo") {
			msg_send.input = INPUT_LEFT_OPEN;
			cout << outMessage[OUTPUT_LEFT_OPEN] << endl;
		} else if (input == "ro") {
			msg_send.input = INPUT_RIGHT_OPEN;
			cout << outMessage[OUTPUT_RIGHT_OPEN] << endl;
		} else if (input == "lc") {
			msg_send.input = INPUT_LEFT_CLOSE;
			cout << outMessage[OUTPUT_LEFT_CLOSE] << endl;
		} else if (input == "rc") {
			msg_send.input = INPUT_RIGHT_CLOSE;
			cout << outMessage[OUTPUT_RIGHT_CLOSE] << endl;
		} else if (input == "glu") {
			msg_send.input = INPUT_LEFT_UNLOCK;

		} else if (input == "gll") {
			msg_send.input = INPUT_LEFT_LOCK;
			cout << outMessage[OUTPUT_LEFT_LOCK] << endl;
		} else if (input == "gru") {
			msg_send.input = INPUT_RIGHT_UNLOCK;
			cout << outMessage[OUTPUT_RIGHT_UNLOCK] << endl;
		} else if (input == "grl") {
			msg_send.input = INPUT_RIGHT_LOCK;
			cout << outMessage[OUTPUT_RIGHT_LOCK] << endl;
		} else if (input == "exit") {
			msg_send.input = INPUT_EXIT;
			if (MsgSend(coid, &msg_send, sizeof(send_t), 0, 0) == -1) {
				cerr << "Message was unable to send " << endl;
				ConnectDetach(coid);
				exit(EXIT_FAILURE);
			}

			ConnectDetach(coid);
			return EXIT_SUCCESS;
		} else {
			cerr << "Please try again,The input is not invalid." << endl;
			continue;
		}

		if (MsgSend(coid, &msg_send, sizeof(msg_send), &msg_receive,
				sizeof(response_t)) == -1) {
			cerr << "MsgSend had an error." << endl;
			exit(EXIT_FAILURE);
		}
	}

	ConnectDetach(coid);
	return EXIT_SUCCESS;
}
